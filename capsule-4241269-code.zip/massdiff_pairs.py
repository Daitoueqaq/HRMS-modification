from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from src.building_block_utils import MASS_DIFFS, allowed_da_error

#Example 1,2,and 3
#DATA_CSV = Path("/data/example_massdiff/Aerobic_sludge_treat.csv")
#DATA_CSV = Path("/data/example_massdiff/e2_2_peaks.csv")
DATA_CSV = Path("/data/example_massdiff/e2_12_peaks.csv")
RESULTS = Path("/results")

def pick_mass_column(df: pd.DataFrame) -> str:
    candidates = [
        "Mass", "mass", "m/z", "mz", "MZ", "MonoisotopicMass", "Monoisotopic Mass",
        "Observed_Mass", "Observed Mass", "ExactMass", "Exact Mass"
    ]
    for c in candidates:
        if c in df.columns:
            return c
    raise ValueError(f"Could not find a mass column. Available columns: {list(df.columns)}")

def load_peaks_from_csv(fp: Path) -> pd.DataFrame:
    if not fp.exists():
        raise FileNotFoundError(f"Missing input file: {fp}")
    df = pd.read_csv(fp)
    mass_col = pick_mass_column(df)
    out = df.copy()
    out[mass_col] = pd.to_numeric(out[mass_col], errors="coerce")
    out = out.dropna(subset=[mass_col]).reset_index(drop=True)
    return out.rename(columns={mass_col: "Mass"})

def find_pairs_for_target(masses: np.ndarray, target_diff: float, ppm_error: float):
    tol = allowed_da_error(target_diff, ppm_error)
    order = np.argsort(masses)
    m_sorted = masses[order]
    pairs = []
    for a_pos, m1 in enumerate(m_sorted):
        lo = m1 + (target_diff - tol)
        hi = m1 + (target_diff + tol)
        left = np.searchsorted(m_sorted, lo, side="left")
        right = np.searchsorted(m_sorted, hi, side="right")
        start = max(left, a_pos + 1)
        for b_pos in range(start, right):
            m2 = m_sorted[b_pos]
            delta = abs(m2 - m1)
            err_da = abs(delta - target_diff)
            err_ppm = err_da / target_diff * 1e6
            pairs.append((order[a_pos], order[b_pos], m1, m2, delta, err_da, err_ppm))
    return pairs

def main():
    RESULTS.mkdir(parents=True, exist_ok=True)

    ppm_error = 100
    targets = {
        "CF2": MASS_DIFFS["CF2"].m_e,
        "CH2": MASS_DIFFS["CH2"].m_e,
        "+F-H": MASS_DIFFS["F_minus_H"].m_e,      }

    df = load_peaks_from_csv(DATA_CSV)
    keep_cols = ["Mass"]
    for col in ["Intensity", "Average Control Intensity", "Average_Control_Intensity"]:
        if col in df.columns:
            keep_cols.append(col)
    df2 = df[keep_cols].copy()
    masses = df2["Mass"].to_numpy(dtype=float)
    all_outputs = []
    per_target_counts = {}
    for name, target_diff in targets.items():
        pairs = find_pairs_for_target(masses, target_diff=target_diff, ppm_error=ppm_error)
        per_target_counts[name] = len(pairs)
        rows = []
        for i, j, m1, m2, delta, err_da, err_ppm in pairs:
            row = {
                "target_name": name,
                "target_diff_Da": target_diff,
                "ppm_tolerance": ppm_error,
                "idx1": int(i),
                "idx2": int(j),
                "Mass1": float(m1),
                "Mass2": float(m2),
                "Delta_Da": float(delta),
                "Error_Da": float(err_da),
                "Error_ppm": float(err_ppm),
            }
            for col in keep_cols:
                if col != "Mass":
                    row[f"{col}_1"] = float(df2.loc[i, col])
                    row[f"{col}_2"] = float(df2.loc[j, col])
            rows.append(row)
        out_df = pd.DataFrame(rows)
        out_path = RESULTS / f"massdiff_pairs_{name}.csv"
        out_df.to_csv(out_path, index=False)
        all_outputs.append(out_df)
        print(f"{name}: wrote {len(out_df)} pairs -> {out_path}")
    combined = pd.concat(all_outputs, ignore_index=True) if all_outputs else pd.DataFrame()
    combined_path = RESULTS / "massdiff_pairs_ALL.csv"
    combined.to_csv(combined_path, index=False)
    meta = {
        "input_file": str(DATA_CSV),
        "n_peaks": int(len(df2)),
        "ppm_error": ppm_error,
        "targets": targets,
        "pairs_per_target": per_target_counts,
        "outputs": {
            "combined": str(combined_path),
        },
    }
    (RESULTS / "massdiff_run_summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"\nSaved combined: {combined_path}")
    print("Saved summary:  /results/massdiff_run_summary.json")

if __name__ == "__main__":
    main()