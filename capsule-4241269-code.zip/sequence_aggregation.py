from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

from src.info_bio_agg_utils import (
    list_fasta_like_files,
    merge_unique_by_sequence,
    dedupe_by_taxon,
    load_taxa_from_seqdump,
    filter_records_by_taxa,
    write_fasta,
    summarize_taxa,
)

def main():
    DATA = Path("/data")
    RESULTS = Path("/results")
    RESULTS.mkdir(parents=True, exist_ok=True)

    input_dir = DATA / "example_sequences"
    seqdump_file = DATA / "seqdump_example.fasta"

    if not input_dir.exists():
        raise FileNotFoundError("Missing /data/input_sequences/. ")
    if not seqdump_file.exists():
        raise FileNotFoundError("Missing /data/seqdump_mod.fasta. ")
    input_files = list_fasta_like_files(input_dir)
    if not input_files:
        raise FileNotFoundError("No .fasta/.fa/.txt found under /data/input_sequences/")
    print("Input files:")
    for f in input_files:
        print("  -", f.name)
    merged_unique_seq = merge_unique_by_sequence(input_files)
    out1 = RESULTS / "01_merged_unique_by_sequence.fasta"
    write_fasta(merged_unique_seq, out1)
    merged_unique_taxon = dedupe_by_taxon(merged_unique_seq)
    out2 = RESULTS / "02_merged_unique_by_taxon.fasta"
    write_fasta(merged_unique_taxon, out2)
    mst_taxa = load_taxa_from_seqdump(seqdump_file)
    filtered, missing = filter_records_by_taxa(merged_unique_taxon, mst_taxa)
    out3 = RESULTS / "03_filtered_by_mst_taxa.fasta"
    write_fasta(filtered, out3)
    taxa_rows = summarize_taxa(merged_unique_taxon)
    df = pd.DataFrame(taxa_rows)
    df.to_csv(RESULTS / "taxa_summary_in_merged_taxon.csv", index=False)

    (RESULTS / "missing_mst_taxa.txt").write_text("\n".join(sorted(missing)) + ("\n" if missing else ""), encoding="utf-8")

    meta = {
        "n_input_files": len(input_files),
        "n_unique_sequences": len(merged_unique_seq),
        "n_unique_taxa": len(merged_unique_taxon),
        "n_mst_taxa": len(mst_taxa),
        "n_filtered_retained": len(filtered),
        "n_missing_mst_taxa": len(missing),
        "outputs": {
            "unique_by_sequence": str(out1),
            "unique_by_taxon": str(out2),
            "filtered_by_mst_taxa": str(out3),
            "taxa_summary_csv": str(RESULTS / "taxa_summary_in_merged_taxon.csv"),
            "missing_taxa_txt": str(RESULTS / "missing_mst_taxa.txt"),
        },
    }
    (RESULTS / "pipeline_summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("\nDONE. Key outputs are in /results.")
    print(json.dumps(meta, indent=2))

if __name__ == "__main__":
    main()