import json
from pathlib import Path
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

def gaussian(x, amp, mu, sigma):
    return amp * np.exp(-((x - mu) ** 2) / (2.0 * sigma ** 2))

def main():
    RESULTS = Path("/results")
    RESULTS.mkdir(parents=True, exist_ok=True)

    x = np.array([
        375.958012, 375.958877, 375.959741, 375.960605, 375.961469,
        375.962333, 375.963198, 375.964062, 375.964926, 375.96579,
        375.966654, 375.967519, 375.968383, 375.969247, 375.970111,
        375.970976, 375.97184, 375.972704, 375.973568, 375.974433,
        375.975297
    ])
    y = np.array([
        0, 0, 0.184505, 7.556952, 37.801184, 60.197814, 54.425075,
        49.873625, 137.742442, 467.566354, 1110.407035, 1877.963781,
        2317.505742, 1922.789927, 1156.743158, 483.944579, 130.883176,
        17.943952, 0.146768, 0, 0
    ])

    initial_guess = [float(np.max(y)), float(x[np.argmax(y)]), float(np.std(x))]
    popt, pcov = curve_fit(gaussian, x, y, p0=initial_guess, maxfev=20000)
    amp, mu, sigma = popt
    se = np.sqrt(np.diag(pcov))
    mu_se = float(se[1]) if len(se) > 1 else None
    out = {"mu": float(mu), "mu_se": mu_se, "amp": float(amp), "sigma": float(sigma)}
    (RESULTS / "gaussian_peak_fit.json").write_text(json.dumps(out, indent=2))
    xx = np.linspace(x.min(), x.max(), 400)
    yy = gaussian(xx, amp, mu, sigma)

    plt.figure()
    plt.scatter(x, y, s=20)
    plt.plot(xx, yy)
    plt.xlabel("m/z")
    plt.ylabel("intensity")
    title = f"Gaussian fit center (mu) = {mu:.9f}"
    if mu_se is not None:
        title += f" ± {mu_se:.2e}"
    plt.title(title)
    plt.tight_layout()
    plt.savefig(RESULTS / "gaussian_peak_fit.png", dpi=300)
    print(f"Center of the peak (mu) = {mu:.9f}")
    if mu_se is not None:
        print(f"Standard error of mu = {mu_se:.3e}")

if __name__ == "__main__":
    main()