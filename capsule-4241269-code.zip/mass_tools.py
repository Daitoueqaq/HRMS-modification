import json
from pathlib import Path
from src.mass_utils import calculate_mass_errors, exact_mass

def main():
    RESULTS = Path("/results")
    RESULTS.mkdir(parents=True, exist_ok=True)
    ####--------------------------------
    formula = "Cn-x+2H5F2n-2x-1O2"
    subs = {"n": 8, "x": 1}
    observed_mz = 392.01230
    ###--------------------------------
    theoretical_mz = exact_mass(formula, subs=subs)
    err = calculate_mass_errors(theoretical_mz, observed_mz)
    out = {
        "formula": formula,
        "subs": subs,
        "theoretical_mz": theoretical_mz,
        "observed_mz": observed_mz,
        "error_mda": err.error_mda,
        "error_ppm": err.error_ppm,
    }
    (RESULTS / "mass_tools_output.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()