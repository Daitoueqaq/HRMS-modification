from __future__ import annotations
from pathlib import Path
import pandas as pd

DATA_DIR = Path("/data/example_spectra")
OUT_DIR = Path("/results/spectra_peak")

def find_local_max_peaks(df: pd.DataFrame, mass_col: str = "Mass", intensity_col: str = "Intensity") -> pd.DataFrame:
    df = df.copy()
    df[mass_col] = pd.to_numeric(df[mass_col], errors="coerce")
    df[intensity_col] = pd.to_numeric(df[intensity_col], errors="coerce")
    df = df.dropna(subset=[mass_col, intensity_col]).reset_index(drop=True)
    if len(df) < 3:
        return pd.DataFrame(columns=[mass_col, intensity_col])
    masses = df[mass_col].to_numpy()
    intens = df[intensity_col].to_numpy()
    mask = (intens[1:-1] > intens[:-2]) & (intens[1:-1] > intens[2:])
    peak_m = masses[1:-1][mask]
    peak_i = intens[1:-1][mask]
    return pd.DataFrame({mass_col: peak_m, intensity_col: peak_i})

def main():
    if not DATA_DIR.exists():
        raise FileNotFoundError(f"Missing folder: {DATA_DIR}. Upload your Excel files into /data/example_spectra/")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    excel_files = sorted(DATA_DIR.glob("*.xlsx"))
    if not excel_files:
        raise FileNotFoundError(f"No .xlsx files found in {DATA_DIR}")
    summary_rows = []
    for fp in excel_files:
        df = pd.read_excel(fp, skiprows=7, engine="openpyxl")
        required_cols = {"Mass", "Intensity"}
        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(
                f"{fp.name} is missing columns {missing}. "
                f"Found columns: {list(df.columns)}. "
                "If the header row is not where you think, adjust skiprows."
            )
        peaks_df = find_local_max_peaks(df, mass_col="Mass", intensity_col="Intensity")
        out_name = fp.stem + "_peaks.csv"
        out_fp = OUT_DIR / out_name
        peaks_df.to_csv(out_fp, index=False)
        summary_rows.append(
            {
                "input_file": fp.name,
                "n_points": int(len(df)),
                "n_peaks": int(len(peaks_df)),
                "output_file": str(out_fp),
            }
        )
        print(f"Wrote {len(peaks_df)} peaks -> {out_fp}")
    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(Path("/results") / "peak_extraction_summary.csv", index=False)
    print("\nSaved summary -> /results/peak_extraction_summary.csv")

if __name__ == "__main__":
    main()