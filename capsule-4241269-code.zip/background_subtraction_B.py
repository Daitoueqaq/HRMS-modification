from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import numpy as np

EXP_DIR = Path("/data/example_peaks")
CTRL_DIR = Path("/data/example_control_peaks")
OUT_DIR = Path("/results/background_subtraction_B")

def _require_cols(df: pd.DataFrame, fp_label: str) -> pd.DataFrame:
    if "Mass" not in df.columns or "Intensity" not in df.columns:
        raise ValueError(f"{fp_label} must contain columns Mass and Intensity. Found: {list(df.columns)}")
    out = df.copy()
    out["Mass"] = pd.to_numeric(out["Mass"], errors="coerce")
    out["Intensity"] = pd.to_numeric(out["Intensity"], errors="coerce")
    out = out.dropna(subset=["Mass", "Intensity"]).reset_index(drop=True)
    return out

def _max_intensity_within_ppm(control_df: pd.DataFrame, target_mz: float, ppm_error: float) -> float:
    mz = control_df["Mass"].to_numpy()
    inten = control_df["Intensity"].to_numpy()
    ppm_diff = np.abs(mz - target_mz) / target_mz * 1e6
    mask = ppm_diff <= ppm_error
    if mask.any():
        return float(inten[mask].max())
    return 0.0

def background_subtraction_B(
    exp_df: pd.DataFrame,
    control_dfs: list[pd.DataFrame],
    control_names: list[str],
    ppm_error: float = 7.5,
    intensity_factor: float = 35.0,
) -> pd.DataFrame:
    exp = exp_df.copy()
    for cname in control_names:
        exp[f"ControlMax__{cname}"] = 0.0
    exp["Average_Control_Intensity"] = 0.0
    exp["Is_Unique_B"] = False
    for i, row in exp.iterrows():
        target_mz = float(row["Mass"])
        exp_int = float(row["Intensity"])
        per_ctrl_max = []
        for cdf, cname in zip(control_dfs, control_names):
            m = _max_intensity_within_ppm(cdf, target_mz, ppm_error)
            exp.at[i, f"ControlMax__{cname}"] = m
            if m > 0:
                per_ctrl_max.append(m)
        avg_ctrl = float(exp[[f"ControlMax__{c}" for c in control_names]].iloc[i].mean())
        exp.at[i, "Average_Control_Intensity"] = avg_ctrl
        exp.at[i, "Is_Unique_B"] = (avg_ctrl * intensity_factor < exp_int)
    unique = exp.loc[exp["Is_Unique_B"]].drop(columns=["Is_Unique_B"])
    return unique

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    ppm_error = 10
    intensity_factor = 25.0

    exp_files = sorted(EXP_DIR.glob("*.csv"))
    ctrl_files = sorted(CTRL_DIR.glob("*.csv"))
    if not exp_files:
        raise FileNotFoundError(f"No experimental peak CSVs found in {EXP_DIR}")
    if not ctrl_files:
        raise FileNotFoundError(f"No control peak CSVs found in {CTRL_DIR}")
    control_dfs = [_require_cols(pd.read_csv(fp), fp.name) for fp in ctrl_files]
    control_names = [fp.stem for fp in ctrl_files]
    combined = []
    for exp_fp in exp_files:
        exp_df = _require_cols(pd.read_csv(exp_fp), exp_fp.name)
        unique_df = background_subtraction_B(
            exp_df=exp_df,
            control_dfs=control_dfs,
            control_names=control_names,
            ppm_error=ppm_error,
            intensity_factor=intensity_factor,
        )
        out_fp = OUT_DIR / f"{exp_fp.stem}__bgsubB.csv"
        unique_df.to_csv(out_fp, index=False)
        tmp = unique_df.copy()
        tmp.insert(0, "Experimental_File", exp_fp.name)
        combined.append(tmp)
        print(f"{exp_fp.name}: input={len(exp_df)} peaks, unique={len(unique_df)} -> {out_fp}")
    combined_df = pd.concat(combined, ignore_index=True) if combined else pd.DataFrame()
    combined_out = OUT_DIR / "ALL_experiments__bgsubB_combined.csv"
    combined_df.to_csv(combined_out, index=False)
    meta = {
        "method": "background_subtraction_B",
        "rule": "keep if exp_intensity > intensity_factor * average(control_max_within_ppm across matched controls)",
        "ppm_error": ppm_error,
        "intensity_factor": intensity_factor,
        "n_experimental_files": len(exp_files),
        "n_control_files": len(ctrl_files),
        "experimental_files": [f.name for f in exp_files],
        "control_files": [f.name for f in ctrl_files],
        "outputs": {
            "per_experiment_folder": str(OUT_DIR),
            "combined_csv": str(combined_out),
        },
    }
    (OUT_DIR / "run_summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"\nSaved combined: {combined_out}")
    print(f"Saved summary:  {OUT_DIR / 'run_summary.json'}")

if __name__ == "__main__":
    main()