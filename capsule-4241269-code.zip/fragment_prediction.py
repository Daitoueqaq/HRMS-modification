import re
import json
from pathlib import Path
import pandas as pd
import numpy as np

DATA_DIR = Path("/data/chemcalc_cache")
RESULTS_DIR = Path("/results")

def elements_from_mfrange(mf_range: str):
    els = []
    for token in mf_range.split():
        m = re.match(r"([A-Za-z]+)", token)
        if m:
            els.append(m.group(1))
    els = sorted(set(els), key=lambda x: (-len(x), x))
    return els

def parse_formula_counts(mf: str, elements):
    counts = {}
    for el in elements:
        m = re.search(rf"{re.escape(el)}(\d*)", mf)
        if not m:
            counts[el] = 0
        else:
            num = m.group(1)
            counts[el] = int(num) if num != "" else 1
    return counts

def load_cached_candidates(mass: float, mass_range: float):
    fname = DATA_DIR / f"chemcalc_mass_{mass:.5f}_mr_{mass_range:g}.csv"
    if not fname.exists():
        raise FileNotFoundError(
            f"Missing cache file: {fname}. "
        )
    df = pd.read_csv(fname)
    if "mf" not in df.columns:
        raise ValueError(f"{fname} missing 'mf' column.")
    return df

def diff_to_string(diff_counts, elements):
    parts = []
    for el in elements:
        v = int(diff_counts[el])
        if v == 1:
            parts.append(f"{el}")
        elif v > 1:
            parts.append(f"{el}{v}")
    return "".join(parts)

def add_element_columns(df: pd.DataFrame, elements):
    out = df.copy()
    for el in elements:
        out[el] = out["mf"].apply(lambda s: parse_formula_counts(str(s), elements)[el])
    return out

def find_chains(formula_tables, elements):
    mats = [t[elements].to_numpy(dtype=int) for t in formula_tables]
    mfs = [t["mf"].astype(str).to_numpy() for t in formula_tables]
    ppms = [t["ppm"].to_numpy() if "ppm" in t.columns else np.full(len(t), np.nan) for t in formula_tables]
    results = []

    def recurse(level, chosen_indices):
        if level == -1:
            idx_chain = chosen_indices[::-1]  # reverse to 0..n-1
            row = {}
            n = len(formula_tables)
            for i in range(n):
                row[f"mf_{i+1}"] = mfs[i][idx_chain[i]]
                row[f"ppm_{i+1}"] = float(ppms[i][idx_chain[i]])
            for i in range(n - 1):
                diff = mats[i + 1][idx_chain[i + 1]] - mats[i][idx_chain[i]]
                diff_counts = {el: int(diff[j]) for j, el in enumerate(elements)}
                row[f"struct_diff_{i+1}_{i+2}"] = diff_to_string(diff_counts, elements)
            results.append(row)
            return

        cur_table_i = level  
        table_idx = cur_table_i
        if len(chosen_indices) == 0:
            for idx in range(len(formula_tables[table_idx])):
                recurse(level - 1, chosen_indices + [idx])
        else:
            later_table_idx = table_idx + 1
            later_idx = chosen_indices[-1]
            later_vec = mats[later_table_idx][later_idx]
            ok = np.all(mats[table_idx] <= later_vec, axis=1)
            eligible = np.where(ok)[0]
            for idx in eligible:
                recurse(level - 1, chosen_indices + [idx])
    n_tables = len(formula_tables)
    recurse(n_tables - 1, [])
    return pd.DataFrame(results)

def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    mode = "four"  # Use "two" | "three" | "four"
    mf_range = "C0-100 H0-200 N0-6 O0-10 F0-50 S0-6 K0-5 P0-5"
    mass_range = 1.0

    if mode == "two":
        masses = [168.98802, 218.98509]
    elif mode == "three":
        mf_range = "C0-100 H0-200 N0-6 O0-10 F0-100 S0-6"
        masses = [118.99120, 168.98807, 268.98233]
    elif mode == "four":
        mf_range = "C0-100 H0-200 N0-6 O0-10 F0-50 S0-6"
        masses = [118.99120, 168.98807, 268.98233, 318.97924]
    else:
        raise ValueError("mode must be 'two', 'three', or 'four'")

    elements = elements_from_mfrange(mf_range)
    tables = []
    for m in masses:
        df = load_cached_candidates(mass=m, mass_range=mass_range)
        df = add_element_columns(df, elements)
        tables.append(df)
    chains = find_chains(tables, elements)
    out_csv = RESULTS_DIR / f"mass_chain_{mode}.csv"
    chains.to_csv(out_csv, index=False)
    meta = {
        "mode": mode,
        "masses": masses,
        "mass_range": mass_range,
        "mf_range": mf_range,
        "elements": elements,
        "n_chains": int(len(chains)),
        "cache_dir": str(DATA_DIR),
    }
    (RESULTS_DIR / f"mass_chain_{mode}_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print(f"Saved: {out_csv}")
    print(chains.head(30).to_string(index=False))

if __name__ == "__main__":
    main()