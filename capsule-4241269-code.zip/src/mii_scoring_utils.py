from __future__ import annotations
import math
import re
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from scipy import stats

@dataclass(frozen=True)
class ScreeningParams:
    ppm_match: float = 5.0
    alpha: float = 0.05
    delta1: float = 0.85
    delta2: float = 0.15
    xi: float = 0.25

def _heaviside(z: float) -> int:
    return 1 if z >= 0 else 0

def bh_adjust_pseudorank(pvals: List[float]) -> List[float]:
    k = len(pvals)
    qs = []
    for ps in pvals:
        R = 1 + sum(_heaviside(pt - ps) for pt in pvals)
        qs.append((k * ps) / R)
    return qs

def csi_for_cycle(pvals: List[float], alpha: float) -> float:
    k = len(pvals)
    if k == 0:
        return 0.0
    qs = bh_adjust_pseudorank(pvals)
    denom = k * (-math.log(alpha))
    eps = 1e-300
    acc = 0.0
    for q in qs:
        if _heaviside(alpha - q):
            acc += -math.log(max(q, eps))
    return float(acc / denom)

def lti_for_cycle(x_cycles: np.ndarray, y_ri: np.ndarray) -> float:
    if len(x_cycles) < 3:
        return 0.0
    slope, intercept, r_value, p_value, std_err = stats.linregress(x_cycles, y_ri)
    r2 = float(r_value ** 2)
    m = float(slope)
    return float(_heaviside(m) * math.tanh(m) * r2)

def ppm_match_mask(masses: np.ndarray, ref_mass: float, ppm: float) -> np.ndarray:
    return (np.abs(masses - ref_mass) / ref_mass * 1e6) <= ppm

def cluster_masses_ppm(all_masses: np.ndarray, ppm: float) -> List[float]:
    if len(all_masses) == 0:
        return []
    m_sorted = np.sort(all_masses)
    clusters = []
    cur = [float(m_sorted[0])]
    def within_ppm(m1, m2):
        return abs(m1 - m2) <= m2 * ppm / 1e6
    for m in m_sorted[1:]:
        if within_ppm(m, np.mean(cur)):
            cur.append(float(m))
        else:
            clusters.append(float(np.mean(cur)))
            cur = [float(m)]
    clusters.append(float(np.mean(cur)))
    return clusters

def parse_timepoint_label(filename: str) -> str:
    name = filename.lower()
    if "ini" in name:
        return "ini"
    for t in ["2", "12", "48", "24"]:
        if re.search(rf"(^|[_\-]){t}($|[_\-])", name):
            return t
    m = re.findall(r"\d+", name)
    return m[-1] if m else filename

def timepoint_order_key(tp: str) -> int:
    if tp == "ini":
        return 0
    try:
        return int(tp)
    except ValueError:
        return 10**9

def load_peak_csv(fp: str) -> pd.DataFrame:
    df = pd.read_csv(fp)
    if "Mass" not in df.columns or "Intensity" not in df.columns:
        raise ValueError(f"{fp} must contain columns Mass and Intensity.")
    df = df.copy()
    df["Mass"] = pd.to_numeric(df["Mass"], errors="coerce")
    df["Intensity"] = pd.to_numeric(df["Intensity"], errors="coerce")
    df = df.dropna(subset=["Mass", "Intensity"]).reset_index(drop=True)
    return df

def extract_intensity_for_feature(df: pd.DataFrame, feature_mass: float, ppm: float) -> float:
    masses = df["Mass"].to_numpy(dtype=float)
    intens = df["Intensity"].to_numpy(dtype=float)
    mask = ppm_match_mask(masses, feature_mass, ppm)
    if mask.any():
        return float(intens[mask].max())
    return 0.0

def compute_scores(
    data: Dict[str, Dict[str, pd.DataFrame]],
    params: ScreeningParams,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    replicates = sorted(data.keys())
    timepoints = sorted({tp for r in replicates for tp in data[r].keys()}, key=timepoint_order_key)
    cycle_index = {tp: i + 1 for i, tp in enumerate(timepoints)}
    all_masses = []
    for r in replicates:
        for tp in timepoints:
            if tp in data[r]:
                all_masses.extend(data[r][tp]["Mass"].astype(float).tolist())
    all_masses = np.array(all_masses, dtype=float)
    feature_centers = cluster_masses_ppm(all_masses, ppm=params.ppm_match)
    rows_wide = []
    rows_long = []
    for fmass in feature_centers:
        raw = {tp: {r: 0.0 for r in replicates} for tp in timepoints}
        for r in replicates:
            for tp in timepoints:
                if tp in data[r]:
                    raw[tp][r] = extract_intensity_for_feature(data[r][tp], fmass, ppm=params.ppm_match)
        all_vals = [raw[tp][r] for tp in timepoints for r in replicates]
        vmax = max(all_vals) if all_vals else 0.0
        if vmax <= 0:
            continue
        ri = {tp: {r: (raw[tp][r] / vmax) for r in replicates} for tp in timepoints}
        mean_ri = {tp: float(np.mean([ri[tp][r] for r in replicates])) for tp in timepoints}
        for tp_n in timepoints:
            n = cycle_index[tp_n]
            if n < 2:
                csi = 0.0
                lti = 0.0
                score = params.delta1 * csi + params.delta2 * lti
            else:
                pvals = []
                for tp_s in timepoints:
                    if cycle_index[tp_s] >= n:
                        break
                    x = np.array([ri[tp_n][r] for r in replicates], dtype=float)
                    y = np.array([ri[tp_s][r] for r in replicates], dtype=float)
                    if np.allclose(x, x[0]) and np.allclose(y, y[0]) and np.isclose(x[0], y[0]):
                        p = 1.0
                    else:
                        t = stats.ttest_ind(x, y, equal_var=False, nan_policy="omit")
                        p = float(t.pvalue) if not np.isnan(t.pvalue) else 1.0
                    pvals.append(p)
                csi = csi_for_cycle(pvals, alpha=params.alpha)
                xs = np.array([cycle_index[t] for t in timepoints if cycle_index[t] <= n], dtype=float)
                ys = np.array([mean_ri[t] for t in timepoints if cycle_index[t] <= n], dtype=float)
                lti = lti_for_cycle(xs, ys)

                score = params.delta1 * csi + params.delta2 * lti

            rows_long.append({
                "Feature_Mass": fmass,
                "Timepoint": tp_n,
                "Cycle_n": cycle_index[tp_n],
                "CSI": csi,
                "LTI": lti,
                "S": score,
                "Is_MII": int(score >= params.xi),
                "Mean_RI": mean_ri[tp_n],
            })
        tp_final = timepoints[-1]
        long_final = [r for r in rows_long if r["Feature_Mass"] == fmass and r["Timepoint"] == tp_final][0]
        wide = {
            "Feature_Mass": fmass,
            "Final_Timepoint": tp_final,
            "Final_Cycle_n": cycle_index[tp_final],
            "CSI_final": long_final["CSI"],
            "LTI_final": long_final["LTI"],
            "S_final": long_final["S"],
            "Is_MII_final": long_final["Is_MII"],
        }
        for tp in timepoints:
            wide[f"Mean_RI_{tp}"] = mean_ri[tp]
            for r in replicates:
                wide[f"Intensity_{r}_{tp}"] = raw[tp][r]
                wide[f"RI_{r}_{tp}"] = ri[tp][r]
        rows_wide.append(wide)
    wide_df = pd.DataFrame(rows_wide)
    long_df = pd.DataFrame(rows_long)
    if not wide_df.empty:
        wide_df = wide_df.sort_values(["Is_MII_final", "S_final"], ascending=[False, False]).reset_index(drop=True)

    return wide_df, long_df