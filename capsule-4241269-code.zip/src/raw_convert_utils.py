from __future__ import annotations
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, Optional
import numpy as np
from pyteomics import mzml

@dataclass(frozen=True)
class MzMLExportConfig:
    ms_level: int = 1
    pick: str = "tic_max"

def _pick_spectrum(reader: mzml.MzML, ms_level: int, pick: str):
    chosen = None
    if pick == "first":
        for spec in reader:
            if spec.get("ms level") == ms_level and "m/z array" in spec and "intensity array" in spec:
                return spec
        return None
    best_tic = -1.0
    for spec in reader:
        if spec.get("ms level") != ms_level:
            continue
        if "m/z array" not in spec or "intensity array" not in spec:
            continue
        inten = np.asarray(spec["intensity array"], dtype=float)
        tic = float(spec.get("total ion current", float(inten.sum())))
        if tic > best_tic:
            best_tic = tic
            chosen = spec
    return chosen

def export_mzml_to_csv(mzml_path: Path, out_csv: Path, cfg: Optional[MzMLExportConfig] = None) -> Dict[str, Any]:
    cfg = cfg or MzMLExportConfig()
    mzml_path = Path(mzml_path)
    out_csv = Path(out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    if not mzml_path.exists():
        raise FileNotFoundError(f"mzML not found: {mzml_path}")
    with mzml.MzML(str(mzml_path)) as reader:
        spec = _pick_spectrum(reader, ms_level=cfg.ms_level, pick=cfg.pick)
    if spec is None:
        raise RuntimeError(f"No usable MS{cfg.ms_level} spectra found in {mzml_path.name}")
    mz_arr = np.asarray(spec["m/z array"], dtype=float)
    in_arr = np.asarray(spec["intensity array"], dtype=float)
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["mz", "intensity"])
        w.writerows(zip(mz_arr.tolist(), in_arr.tolist()))
    return {
        "input": str(mzml_path),
        "output": str(out_csv),
        "ms_level": cfg.ms_level,
        "pick": cfg.pick,
        "n_points": int(len(mz_arr)),
    }