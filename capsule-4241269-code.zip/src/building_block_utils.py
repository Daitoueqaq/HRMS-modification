from __future__ import annotations
from dataclasses import dataclass
from typing import Dict

@dataclass(frozen=True)
class MassDiff:
    name: str
    m_e: float 
    m_n: float 

MASS_DIFFS: Dict[str, MassDiff] = {
    "CF2": MassDiff("CF2", 49.99681, 50),
    "CH2": MassDiff("CH2", 14.01565, 14),
    "F2": MassDiff("F2", 37.99681, 38),
    "H2": MassDiff("H2", 2.01565, 2),
    "F_minus_H": MassDiff("+F−H", 17.99058, 18),
    "C2H4O": MassDiff("C2H4O", 44.02621, 44),
    "13C_12C": MassDiff("13C/12C", 1.00335, 1),
    "34S_32S": MassDiff("34S/32S", 1.99580, 2),
}

def allowed_da_error(target_diff_da: float, ppm_error: float) -> float:
    return target_diff_da * ppm_error / 1e6

def diff_matches_target(m1: float, m2: float, target_diff_da: float, ppm_error: float) -> bool:
    actual = abs(m1 - m2)
    tol = allowed_da_error(target_diff_da, ppm_error)
    return abs(actual - target_diff_da) <= tol