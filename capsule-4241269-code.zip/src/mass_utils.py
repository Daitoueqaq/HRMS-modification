from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Dict, Optional, Union
import sympy as sp

ATOMIC_MASS: Dict[str, float] = {
    "H": 1.00782503223,
    "C": 12.0,
    "N": 14.003074,
    "O": 15.99491463,
    "F": 18.99840322,
    "P": 30.973762,
    "S": 31.9720707,
    "Cl": 34.96885272,
    "Br": 78.9183361,
    "I": 126.904473,
    "Na": 22.9897677,
    "Mg": 23.9850423,
    "Al": 26.9815386,
    "Si": 27.9769265,
}

@dataclass
class MassError:
    error_mda: float
    error_ppm: float

def calculate_mass_errors(theoretical_mz: float, observed_mz: float) -> MassError:
    error_da = observed_mz - theoretical_mz
    return MassError(
        error_mda=float(error_da * 1000.0),
        error_ppm=float((error_da / theoretical_mz) * 1e6),
    )

def _to_sympy_mul(expr: str) -> str:
    return re.sub(r"(?<=\d)(?=[A-Za-z])", "*", expr)

def exact_mass(
    formula: str,
    *,
    atomic_mass: Optional[Dict[str, float]] = None,
    subs: Optional[Dict[str, Union[int, float]]] = None,
) -> Union[float, sp.Expr]:
    am = atomic_mass or ATOMIC_MASS
    total = sp.Integer(0)
    i = 0
    n = len(formula)
    while i < n:
        if formula[i].isspace():
            i += 1
            continue
        if not formula[i].isupper():
            raise ValueError(
                f"Unexpected character '{formula[i]}' at position {i}. "
                "Formula must use element symbols beginning with uppercase letters."
            )
        elem = formula[i]
        if i + 1 < n and formula[i + 1].islower():
            cand = formula[i : i + 2]
            if cand in am:
                elem = cand
                i += 2
            else:
                elem = formula[i]
                i += 1
        else:
            i += 1
        count_str = ""
        while i < n and not formula[i].isupper():
            count_str += formula[i]
            i += 1
        count_str = count_str.strip()
        if count_str == "":
            count_expr = sp.Integer(1)
        else:
            count_expr = sp.sympify(_to_sympy_mul(count_str))
        if elem not in am:
            raise KeyError(f"Element '{elem}' not in ATOMIC_MASS. Consider add it to the dictionary.")
        total += sp.Float(am[elem]) * count_expr

    if subs:
        total = total.subs(subs)
    if len(total.free_symbols) == 0:
        return float(total)

    return sp.simplify(total)