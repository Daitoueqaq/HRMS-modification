from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
import re
from typing import Iterable, List, Set, Tuple
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

FASTA_EXTS = (".fasta", ".fa", ".txt")
BRACKET_TAXON = re.compile(r"\[([^]]+)\]")

def list_fasta_like_files(input_dir: Path, exts: Tuple[str, ...] = FASTA_EXTS) -> List[Path]:
    files = []
    for p in sorted(input_dir.iterdir()):
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)
    return files

def merge_unique_by_sequence(files: Iterable[Path]) -> List[SeqRecord]:
    unique = OrderedDict()
    total = 0
    for fp in files:
        n = 0
        for rec in SeqIO.parse(str(fp), "fasta"):
            seq = str(rec.seq)
            if seq not in unique:
                unique[seq] = rec
            n += 1
            total += 1
        print(f"Read {n} records from {fp.name}")
    print(f"Total records parsed: {total}")
    print(f"Unique sequences retained: {len(unique)}")
    return list(unique.values())

def taxon_from_record(rec: SeqRecord) -> str:
    m = BRACKET_TAXON.search(rec.description or "")
    return m.group(1).strip() if m else rec.id

def dedupe_by_taxon(records: Iterable[SeqRecord]) -> List[SeqRecord]:
    seen: Set[str] = set()
    out: List[SeqRecord] = []
    total = 0
    for rec in records:
        total += 1
        taxon = taxon_from_record(rec)
        if taxon not in seen:
            seen.add(taxon)
            out.append(rec)
    print(f"Processed {total} records for taxon-dedupe.")
    print(f"Unique taxa retained: {len(out)}")
    return out

def load_taxa_from_seqdump(seqdump_fasta: Path) -> Set[str]:
    taxa: Set[str] = set()
    for rec in SeqIO.parse(str(seqdump_fasta), "fasta"):
        taxa.add(rec.description.strip())
    print(f"Found {len(taxa)} taxa in {seqdump_fasta.name}")
    return taxa

def filter_records_by_taxa(records: Iterable[SeqRecord], keep_taxa: Set[str]) -> Tuple[List[SeqRecord], Set[str]]:
    seen: Set[str] = set()
    out: List[SeqRecord] = []
    for rec in records:
        taxon = taxon_from_record(rec)
        if taxon in keep_taxa and taxon not in seen:
            seen.add(taxon)
            out.append(rec)
    missing = keep_taxa - seen
    print(f"Filtered records retained: {len(out)}")
    print(f"Missing taxa (in MST list but not found in merged): {len(missing)}")
    return out, missing

def write_fasta(records: Iterable[SeqRecord], outpath: Path) -> None:
    outpath.parent.mkdir(parents=True, exist_ok=True)
    SeqIO.write(list(records), str(outpath), "fasta")
    print(f"Wrote: {outpath}")

def summarize_taxa(records: Iterable[SeqRecord]) -> List[dict]:
    counts = {}
    for rec in records:
        t = taxon_from_record(rec)
        counts[t] = counts.get(t, 0) + 1

    rows = [{"taxon": t, "count": counts[t]} for t in sorted(counts)]
    return rows