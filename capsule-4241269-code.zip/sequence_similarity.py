from __future__ import annotations
from pathlib import Path
from Bio import SeqIO, pairwise2
import pandas as pd

DATA = Path("/data")
RESULTS = Path("/results")

def calculate_identity(seq1: str, seq2: str) -> float:
    aln = pairwise2.align.globalxx(seq1, seq2, one_alignment_only=True)[0]
    aligned_seq1, aligned_seq2, score, start, end = aln
    matches = sum(1 for a, b in zip(aligned_seq1, aligned_seq2) if a == b)
    return matches / len(aligned_seq1) * 100.0

def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    fasta_file = DATA / "seqdump_example.fasta"
    if not fasta_file.exists():
        raise FileNotFoundError("Missing /data/seqdump_example.fasta. Upload it to the data folder.")

    threshold = 90.0  ##### percent identity cutoff

    sequences = list(SeqIO.parse(str(fasta_file), "fasta"))
    print(f"Loaded {len(sequences)} sequences from {fasta_file}")

    hits = []
    for i, rec1 in enumerate(sequences):
        s1 = str(rec1.seq)
        for rec2 in sequences[i + 1 :]:
            s2 = str(rec2.seq)
            pid = calculate_identity(s1, s2)
            if pid >= threshold:
                hits.append(
                    {
                        "seq1_id": rec1.id,
                        "seq1_desc": rec1.description,
                        "seq2_id": rec2.id,
                        "seq2_desc": rec2.description,
                        "percent_identity": pid,
                    }
                )
                print(f"{rec1.id} vs {rec2.id}: {pid:.2f}%")
    out_txt = RESULTS / "pairs_identity_90.txt"
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(f"Pairs with >= {threshold:.1f}% identity\n")
        f.write(f"Input: {fasta_file}\n")
        f.write(f"Total sequences: {len(sequences)}\n")
        f.write(f"Hits: {len(hits)}\n\n")
        for row in hits:
            f.write(f"{row['seq1_desc']}  <->  {row['seq2_desc']}: {row['percent_identity']:.2f}%\n")

    print(f"Saved: {out_txt}")

if __name__ == "__main__":
    main()