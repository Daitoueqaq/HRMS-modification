from __future__ import annotations
from pathlib import Path
import zipfile
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from cartopy.io import shapereader

DATA = Path("/data")
RESULTS = Path("/results")
RESULTS.mkdir(parents=True, exist_ok=True)

AQUATIC_DATA_PATH = DATA / "aqua_summary_1.csv"
WWTP_DATA_PATH = DATA / "wwtp_summary_1.csv"

# Intermediate files (for aquatic and wwtp)
# AQUATIC_Intermediate_Data = DATA / "aqua_summary_0.csv"
# WWTP_Intermediate_Data = DATA / "wwtp_summary_0.csv"

NE_DIR = DATA / "natural_earth"
NE_SHP = NE_DIR / "ne_110m_admin_0_countries.shp"
NE_ZIP = NE_DIR / "ne_110m_admin_0_countries.zip"  
OUTPUT_IMAGE_PATH = RESULTS / "merged_aquatic_wwtp_world_map.png"

def load_world_geometries():
    NE_DIR.mkdir(parents=True, exist_ok=True)
    if (not NE_SHP.exists()) and NE_ZIP.exists():
        with zipfile.ZipFile(NE_ZIP, "r") as z:
            z.extractall(NE_DIR)
    if not NE_SHP.exists():
        raise FileNotFoundError(
            "Missing Natural Earth shapefile. Upload these files to /data/natural_earth/:\n"
            "  ne_110m_admin_0_countries.shp\n"
            "  ne_110m_admin_0_countries.shx\n"
            "  ne_110m_admin_0_countries.dbf\n"
            "  ne_110m_admin_0_countries.prj\n"
            "Or upload ne_110m_admin_0_countries.zip into /data/natural_earth/."
        )
    reader = shapereader.Reader(str(NE_SHP))
    geoms = list(reader.geometries())
    return geoms

def load_aquatic(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing aquatic file: {path} (upload aquasummary_1.csv to /data)")
    df = pd.read_csv(path).copy()
    required = {"latitude", "longitude", "significant_hit_count"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Aquatic file missing columns: {missing}. Found columns: {list(df.columns)}")
    df = df[df["significant_hit_count"] > 0].copy()
    bins = [-float("inf"), 1, 10, 20, 30, 40, 50, 60, 100, 200, float("inf")]
    labels = ["1", "2-10", "11-20", "21-30", "31-40", "41-50", "51-60", "61-100", "100-200", ">200"]
    df["Hit_Category"] = pd.cut(df["significant_hit_count"], bins=bins, labels=labels, right=True)
    size_values = {
        "1": 28, "2-10": 32, "11-20": 34, "21-30": 36, "31-40": 38,
        "41-50": 40, "51-60": 45, "61-100": 55, "100-200": 65, ">200": 80
    }
    df["PointSize"] = df["Hit_Category"].map(size_values)
    df = df.rename(columns={
        "latitude": "Latitude",
        "longitude": "Longitude",
        "significant_hit_count": "Aquatic_Hits"
    })
    return df

def load_wwtp(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing WWTP file: {path} (upload aggregated_hmmsearch...csv to /data)")
    df = pd.read_csv(path).copy()
    required = {"Latitude_Rounded", "Longitude_Rounded", "Hit_Count"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"WWTP file missing columns: {missing}. Found columns: {list(df.columns)}")
    df = df.rename(columns={
        "Latitude_Rounded": "Latitude",
        "Longitude_Rounded": "Longitude",
        "Hit_Count": "WWTP_Hits"
    })
    df = df[df["WWTP_Hits"] > 0].copy()
    bins = [-float("inf"), 1, 10, 20, 30, 40, 50, 60, 100, 200, float("inf")]
    labels = ["1", "2-10", "11-20", "21-30", "31-40", "41-50", "51-60", "61-100", "100-200", ">200"]
    df["Hit_Category"] = pd.cut(df["WWTP_Hits"], bins=bins, labels=labels, right=True)
    size_values = {
        "1": 26, "2-10": 29, "11-20": 32, "21-30": 35, "31-40": 38,
        "41-50": 41, "51-60": 44, "61-100": 52, "100-200": 60, ">200": 68
    }
    df["PointSize"] = df["Hit_Category"].map(size_values)
    return df

def log_tick_list(series: pd.Series) -> list[float]:
    smin = float(series.min())
    smax = float(series.max())
    min_tick = 10 ** np.floor(np.log10(smin))
    max_tick = 10 ** np.ceil(np.log10(smax))
    return [10 ** i for i in range(int(np.log10(min_tick)), int(np.log10(max_tick)) + 1)]

def create_merged_publication_map(aq: pd.DataFrame, ww: pd.DataFrame, world_geoms):
    fig, ax = plt.subplots(
        figsize=(14, 7),
        subplot_kw={"projection": ccrs.Robinson(central_longitude=-15)}
    )
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#E9FAFF")
    ax.set_global()
    ax.add_geometries(
        world_geoms,
        crs=ccrs.PlateCarree(),
        facecolor="#E7FCF8",
        edgecolor="#2B2B2B",
        linewidth=0.35,
        zorder=1,
    )
    ax.add_geometries(
        world_geoms,
        crs=ccrs.PlateCarree(),
        facecolor="none",
        edgecolor="#454545",
        linewidth=0.30,
        zorder=2,
    )
    gl = ax.gridlines(
        crs=ccrs.PlateCarree(),
        draw_labels=True,
        linewidth=0.85,
        color="gray",
        alpha=0.65,
        linestyle="--",
    )
    gl.top_labels = False
    gl.right_labels = False
    gl.xlocator = mticker.FixedLocator([-180, -120, -60, 0, 60, 120, 180])
    gl.xlabel_style = {"size": 18, "color": "gray"}
    gl.ylabel_style = {"size": 18, "color": "gray"}
    aquatic_colors = ["#FFEE32", "#FC825A", "#FB5069", "#6758E0", "#3526A4"]
    aquatic_cmap = mcolors.LinearSegmentedColormap.from_list("aquatic_gradient", aquatic_colors)
    aquatic_norm = mcolors.LogNorm(vmin=aq["Aquatic_Hits"].min(), vmax=aq["Aquatic_Hits"].max())
    sc_aq = ax.scatter(
        aq["Longitude"], aq["Latitude"],
        s=aq["PointSize"],
        c=aq["Aquatic_Hits"],
        cmap=aquatic_cmap,
        norm=aquatic_norm,
        alpha=0.75,
        edgecolor="#242424",
        linewidth=0.45,
        marker="o",
        transform=ccrs.PlateCarree(),
        zorder=10,
        label="Aquatic",
    )
    wwtp_colors = ["#C7F9CC", "#80ED99", "#38A3A5", "#22577A"]
    wwtp_cmap = mcolors.LinearSegmentedColormap.from_list("wwtp_gradient", wwtp_colors)
    wwtp_norm = mcolors.LogNorm(vmin=ww["WWTP_Hits"].min(), vmax=ww["WWTP_Hits"].max())
    sc_ww = ax.scatter(
        ww["Longitude"], ww["Latitude"],
        s=ww["PointSize"],
        c=ww["WWTP_Hits"],
        cmap=wwtp_cmap,
        norm=wwtp_norm,
        alpha=0.75,
        edgecolor="#111111",
        linewidth=0.50,
        marker="D",
        transform=ccrs.PlateCarree(),
        zorder=11,
        label="WWTP",
    )
    cax_aq = inset_axes(
        ax, width="2.2%", height="45%",
        loc="lower left",
        bbox_to_anchor=(1.03, -0.04, 1, 1),
        bbox_transform=ax.transAxes, borderpad=0,
    )
    cb_aq = fig.colorbar(sc_aq, cax=cax_aq, orientation="vertical", ticks=log_tick_list(aq["Aquatic_Hits"]))
    cb_aq.formatter = mticker.LogFormatter()
    cb_aq.update_ticks()
    cb_aq.set_label("Aquatic Total Hit Count", fontsize=17.4, rotation=90, labelpad=8)
    cb_aq.ax.tick_params(labelsize=12)
    cb_aq.ax.minorticks_off()
    cax_ww = inset_axes(
        ax, width="2.2%", height="45%",
        loc="upper left",
        bbox_to_anchor=(1.03, -0.02, 1, 1),
        bbox_transform=ax.transAxes, borderpad=0,
    )
    cb_ww = fig.colorbar(sc_ww, cax=cax_ww, orientation="vertical", ticks=log_tick_list(ww["WWTP_Hits"]))
    cb_ww.formatter = mticker.LogFormatter()
    cb_ww.update_ticks()
    cb_ww.set_label("WWTP Total Hit Count", fontsize=17.4, rotation=90, labelpad=8)
    cb_ww.ax.tick_params(labelsize=12)
    cb_ww.ax.minorticks_off()
    ax.legend(
        loc="lower left",
        bbox_to_anchor=(-0.05, -0.06),
        frameon=True,
        framealpha=0.8,
        facecolor="white",
        edgecolor="#444444",
        fontsize=15,
    )
    return fig, ax

def main():
    aquatic_df = load_aquatic(AQUATIC_DATA_PATH)
    wwtp_df = load_wwtp(WWTP_DATA_PATH)
    if aquatic_df.empty:
        raise RuntimeError("Aquatic dataset empty (>0 hits).")
    if wwtp_df.empty:
        raise RuntimeError("WWTP dataset empty (>0 hits).")
    world_geoms = load_world_geometries()
    fig, ax = create_merged_publication_map(aquatic_df, wwtp_df, world_geoms)
    fig.savefig(OUTPUT_IMAGE_PATH, dpi=1500, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved merged map to: {OUTPUT_IMAGE_PATH}")

if __name__ == "__main__":
    main()