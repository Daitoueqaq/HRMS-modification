from __future__ import annotations
from pathlib import Path
import pandas as pd

DATA = Path("/data")
RESULTS = Path("/results")

def compute_kendrick_metrics(observed_mass: float, ratio: float) -> tuple[float, float]:
    km = observed_mass * ratio
    kmd = km - round(km)
    return km, kmd

def load_input_table() -> pd.DataFrame:
    fp = DATA / "observed_masses.csv"
    if fp.exists():
        df = pd.read_csv(fp)
        if "Observed_Mass" not in df.columns:
            raise ValueError("Input CSV must contain column 'Observed_Mass'.")
        if "Compound" not in df.columns:
            # If not provided, create an index-like label
            df["Compound"] = [f"row_{i+1}" for i in range(len(df))]
        return df[["Compound", "Observed_Mass"]].copy()

    #An example
    data = {
        "Compound": ["1", "2", "3", "4"],
        "Observed_Mass": [312.97282, 262.97587, 212.97872, 162.98152],
    }
    return pd.DataFrame(data)

#Here CF2 repeating block is used
def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    nominal_building_block = 50.0000
    exact_building_block = 49.99680632
    kendrick_ratio = nominal_building_block / exact_building_block
    df = load_input_table()
    km_list = []
    kmd_list = []
    for m in df["Observed_Mass"]:
        km, kmd = compute_kendrick_metrics(float(m), kendrick_ratio)
        km_list.append(km)
        kmd_list.append(kmd)
    df["Kendrick_Mass"] = km_list
    df["Kendrick_Mass_Defect"] = kmd_list
    out_csv = RESULTS / "kendrick_metrics.csv"
    df.to_csv(out_csv, index=False)

    print(df.to_string(index=False))
    print(f"\nSaved: {out_csv}")

if __name__ == "__main__":
    main()