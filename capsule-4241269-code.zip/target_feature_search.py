from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

DATA_DIR = Path("/data/example_peaks")
RESULTS_DIR = Path("/results")

def calculate_ppm(spec_mass: float, ref_mass: float) -> float:
    return abs((spec_mass - ref_mass) / ref_mass * 1e6)

def find_peak_in_files(directory_path: Path, target_mass: float, ppm_tol: float = 10.0) -> pd.DataFrame:
    if not directory_path.exists():
        raise FileNotFoundError(f"Missing directory: {directory_path}")
    csv_files = sorted(directory_path.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv files found in: {directory_path}")
    rows = []
    for fp in csv_files:
        df = pd.read_csv(fp)
        if "Mass" not in df.columns or "Intensity" not in df.columns:
            raise ValueError(
                f"{fp.name} must contain columns Mass and Intensity. Found: {list(df.columns)}"
            )
        mass_series = pd.to_numeric(df["Mass"], errors="coerce")
        inten_series = pd.to_numeric(df["Intensity"], errors="coerce")
        df = df.assign(Mass=mass_series, Intensity=inten_series).dropna(subset=["Mass", "Intensity"])
        ppm_diff = (df["Mass"] - target_mass).abs() / target_mass * 1e6
        hits = df.loc[ppm_diff <= ppm_tol, ["Mass", "Intensity"]].copy()
        hits["ppm_diff"] = ppm_diff.loc[hits.index].values
        hits["file"] = fp.name
        for _, r in hits.iterrows():
            rows.append(
                {
                    "File": r["file"],
                    "Observed_Mass": float(r["Mass"]),
                    "Intensity": float(r["Intensity"]),
                    "Mass_Difference_ppm (before_Gaussian_fit)": float(r["ppm_diff"]),
                    "Target_Mass": float(target_mass),
                    "PPM_Tolerance": float(ppm_tol),
                }
            )
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values(by=["Mass_Difference_ppm (before_Gaussian_fit)", "Intensity"], ascending=[True, False]).reset_index(drop=True)
    return out

def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    target_mass = 500.00258
    ppm_tol = 10.0
    matches = find_peak_in_files(DATA_DIR, target_mass=target_mass, ppm_tol=ppm_tol)
    out_csv = RESULTS_DIR / f"target_peak_matches_{target_mass:.5f}.csv"
    matches.to_csv(out_csv, index=False)
    summary = {
        "input_dir": str(DATA_DIR),
        "target_mass": target_mass,
        "ppm_tolerance": ppm_tol,
        "n_files_scanned": len(list(DATA_DIR.glob("*.csv"))),
        "n_matches": int(len(matches)),
        "output_csv": str(out_csv),
    }
    (RESULTS_DIR / f"target_peak_matches_{target_mass:.5f}_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(matches.head(50).to_string(index=False))
    print(f"\nSaved: {out_csv}")
    print(f"Saved: {RESULTS_DIR / f'target_peak_matches_{target_mass:.5f}_summary.json'}")

if __name__ == "__main__":
    main()