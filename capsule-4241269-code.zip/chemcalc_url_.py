import json
from pathlib import Path
import pandas as pd

def main():
    DATA = Path("/data")
    RESULTS = Path("/results")
    RESULTS.mkdir(parents=True, exist_ok=True)

    mf_range = "C0-100 H0-200 N0-6 O0-10 F0-50 S0-5 K0-1 P0-2"
    mass = 500.00258
    mass_range = 0.1

    cached_csv = DATA / "chemcalc_candidates.csv"
    df = pd.read_csv(cached_csv)
    df.to_csv(RESULTS / "chemcalc_candidates.csv", index=False)
    summary = {
        "query_mass": mass,
        "mass_range": mass_range,
        "mf_range": mf_range,
        "n_candidates": int(len(df)),
        "mode": "offline_cached",
        "cached_source": str(cached_csv),
    }
    (RESULTS / "chemcalc_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(df.head(30).to_string(index=False))
    print("\nSaved: /results/chemcalc_candidates.csv")
    print("Saved: /results/chemcalc_summary.json")

if __name__ == "__main__":
    main()