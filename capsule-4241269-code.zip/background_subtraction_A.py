from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

EXP_DIR = Path("/data/example_peaks")
CTRL_DIR = Path("/data/example_control_peaks")
OUT_DIR = Path("/results/background_subtraction_A")

def ppm(mz: float, ref_mz: float) -> float:
    return abs((mz - ref_mz) / ref_mz * 1e6)

def find_unique_peaks(
    experimental_df: pd.DataFrame,
    control_dfs: list[pd.DataFrame],
    control_names: list[str],
    ppm_error: float = 10.0,
    intensity_factor: float = 50.0,
) -> pd.DataFrame:
    exp_df = experimental_df.copy()
    for col in ("Mass", "Intensity"):
        if col not in exp_df.columns:
            raise ValueError(f"Experimental df missing required column '{col}'.")
    exp_df["Mass"] = pd.to_numeric(exp_df["Mass"], errors="coerce")
    exp_df["Intensity"] = pd.to_numeric(exp_df["Intensity"], errors="coerce")
    exp_df = exp_df.dropna(subset=["Mass", "Intensity"]).reset_index(drop=True)
    for name in control_names:
        exp_df[f"Control_Intensity__{name}"] = 0.0

    is_unique = []
    for i, exp_peak in exp_df.iterrows():
        exp_mz = float(exp_peak["Mass"])
        exp_intensity = float(exp_peak["Intensity"])
        ok = True
        for ctrl_df, ctrl_name in zip(control_dfs, control_names):
            # Validate and normalize control df once
            # (Assume already normalized before call)
            mzs = ctrl_df["Mass"].to_numpy()
            intens = ctrl_df["Intensity"].to_numpy()
            diffs = abs((mzs - exp_mz) / exp_mz * 1e6)
            mask = diffs <= ppm_error
            if mask.any():
                max_ctrl_intensity = float(intens[mask].max())
                exp_df.at[i, f"Control_Intensity__{ctrl_name}"] = max_ctrl_intensity
                if max_ctrl_intensity * intensity_factor >= exp_intensity:
                    ok = False
                    break
            else:
                exp_df.at[i, f"Control_Intensity__{ctrl_name}"] = 0.0
        is_unique.append(ok)
    exp_df["Is_Unique"] = is_unique
    unique_peaks = exp_df.loc[exp_df["Is_Unique"]].drop(columns=["Is_Unique"])
    return unique_peaks

def load_peaks_csv(fp: Path) -> pd.DataFrame:
    df = pd.read_csv(fp)
    if "Mass" not in df.columns or "Intensity" not in df.columns:
        raise ValueError(f"{fp.name} must contain columns Mass and Intensity. Found: {list(df.columns)}")
    df = df.copy()
    df["Mass"] = pd.to_numeric(df["Mass"], errors="coerce")
    df["Intensity"] = pd.to_numeric(df["Intensity"], errors="coerce")
    df = df.dropna(subset=["Mass", "Intensity"]).reset_index(drop=True)
    return df

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    ppm_error = 10.0
    intensity_factor = 50.0

    if not EXP_DIR.exists():
        raise FileNotFoundError(f"Missing experimental directory: {EXP_DIR}")
    if not CTRL_DIR.exists():
        raise FileNotFoundError(f"Missing control directory: {CTRL_DIR}")
    exp_files = sorted(EXP_DIR.glob("*.csv"))
    ctrl_files = sorted(CTRL_DIR.glob("*.csv"))
    if not exp_files:
        raise FileNotFoundError(f"No experimental peak CSV files found in {EXP_DIR}")
    if not ctrl_files:
        raise FileNotFoundError(f"No control peak CSV files found in {CTRL_DIR}")
    control_dfs = [load_peaks_csv(fp) for fp in ctrl_files]
    control_names = [fp.stem for fp in ctrl_files]

    combined_rows = []

    for exp_fp in exp_files:
        exp_df = load_peaks_csv(exp_fp)
        unique_df = find_unique_peaks(
            experimental_df=exp_df,
            control_dfs=control_dfs,
            control_names=control_names,
            ppm_error=ppm_error,
            intensity_factor=intensity_factor,
        )
        out_fp = OUT_DIR / f"{exp_fp.stem}__bgsubA.csv"
        unique_df.to_csv(out_fp, index=False)
        tmp = unique_df.copy()
        tmp.insert(0, "Experimental_File", exp_fp.name)
        combined_rows.append(tmp)
        print(f"{exp_fp.name}: input={len(exp_df)} peaks, unique={len(unique_df)} -> {out_fp}")
    combined = pd.concat(combined_rows, ignore_index=True) if combined_rows else pd.DataFrame()
    combined_out = OUT_DIR / "ALL_experiments__bgsubA_combined.csv"
    combined.to_csv(combined_out, index=False)
    meta = {
        "experimental_dir": str(EXP_DIR),
        "control_dir": str(CTRL_DIR),
        "n_experimental_files": len(exp_files),
        "n_control_files": len(ctrl_files),
        "ppm_error": ppm_error,
        "intensity_factor": intensity_factor,
        "outputs": {
            "per_experiment_folder": str(OUT_DIR),
            "combined_csv": str(combined_out),
        },
        "control_files": [f.name for f in ctrl_files],
        "experimental_files": [f.name for f in exp_files],
    }
    (OUT_DIR / "run_summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"\nSaved combined: {combined_out}")
    print(f"Saved summary:  {OUT_DIR / 'run_summary.json'}")

if __name__ == "__main__":
    main()