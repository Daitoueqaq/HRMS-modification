####
####Example running will takes 12~16 min with example dataset
####

from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

from src.mii_scoring_utils import (
    ScreeningParams,
    parse_timepoint_label,
    timepoint_order_key,
    load_peak_csv,
    compute_scores,
)
E2_DIR = Path("/data/example_features_after_bgsub") 
E1_DIR = Path("/data/example_peaks_1") 
OUT_DIR = Path("/results/mii_scoring")

def load_series(dir_path: Path) -> dict[str, pd.DataFrame]:
    files = sorted(dir_path.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV files found in {dir_path}")
    out = {}
    for fp in files:
        tp = parse_timepoint_label(fp.name)
        out[tp] = load_peak_csv(str(fp))
    return out

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    params = ScreeningParams(
        ppm_match=5.0,
        alpha=0.05,
        delta1=0.85,
        delta2=0.15,
        xi=0.25,
    )
    data = {
        "E2": load_series(E2_DIR),
        "E1": load_series(E1_DIR),
    }
    tps = sorted({tp for r in data for tp in data[r].keys()}, key=timepoint_order_key)
    print("Detected timepoints:", tps)
    wide_df, long_df = compute_scores(data, params=params)
    wide_out = OUT_DIR / "mii_scores_by_feature.csv"
    long_out = OUT_DIR / "mii_scores_by_feature_long.csv"
    wide_df.to_csv(wide_out, index=False)
    long_df.to_csv(long_out, index=False)
    summary = {
        "replicates": list(data.keys()),
        "timepoints": tps,
        "params": {
            "ppm_match": params.ppm_match,
            "alpha": params.alpha,
            "delta1": params.delta1,
            "delta2": params.delta2,
            "xi": params.xi,
        },
        "n_features": int(len(wide_df)),
        "n_mii_final": int((wide_df["Is_MII_final"] == 1).sum()) if not wide_df.empty else 0,
        "outputs": {
            "wide": str(wide_out),
            "long": str(long_out),
        },
        "note": "With only two replicates (E1,E2), t-tests are low-power; use triplicates for manuscript-grade CSI.",
    }
    (OUT_DIR / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"Saved: {wide_out}")
    print(f"Saved: {long_out}")
    print(f"Saved: {OUT_DIR / 'run_summary.json'}")

if __name__ == "__main__":
    main()