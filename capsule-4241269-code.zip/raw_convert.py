from __future__ import annotations
import json
from pathlib import Path
from src.raw_convert_utils import export_mzml_to_csv, MzMLExportConfig

IN_DIR = Path("/data/example_raw")
OUT_DIR = Path("/results/raw_convert")

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    mzml_files = sorted(list(IN_DIR.glob("*.mzML")) + list(IN_DIR.glob("*.mzml")))
    if not mzml_files:
        raise FileNotFoundError("No .mzML/.mzml files found in /data/example_raw/")
    cfg = MzMLExportConfig(ms_level=1, pick="tic_max")  # robust default
    meta = []
    for fp in mzml_files:
        out_csv = OUT_DIR / f"{fp.stem}_mz_intensity.csv"
        info = export_mzml_to_csv(fp, out_csv, cfg=cfg)
        meta.append(info)
        print(f"{fp.name} -> {out_csv.name} ({info['n_points']} points)")
    (OUT_DIR / "mzml_export_summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"\nSaved summary: {OUT_DIR / 'mzml_export_summary.json'}")

if __name__ == "__main__":
    main()