from __future__ import annotations
import re
from pathlib import Path
import numpy as np
import pandas as pd

DATA_DIR = Path("/data/example_features_after_bgsub")
RESULTS_DIR = Path("/results")

def ppm_error(mz: float, ref_mz: float) -> float:
    return abs((mz - ref_mz) / ref_mz * 1e6)

def find_matching_intensity(ref_mass: float, df: pd.DataFrame, ppm_tol: float) -> float:
    masses = df["Mass"].to_numpy()
    intens = df["Intensity"].to_numpy()
    diffs = np.abs(masses - ref_mass) / ref_mass * 1e6
    mask = diffs <= ppm_tol
    if mask.any():
        return float(intens[mask].max())
    return 0.0

def format_intensity_change(intensity_map: dict[str, float]):
    items = list(intensity_map.items())
    change_data = {}
    zero_count = 0
    peak_over_threshold = False
    for i, (tp, intensity) in enumerate(items):
        if intensity > 3000:
            peak_over_threshold = True
        if intensity == 0:
            zero_count += 1
        change_data[f"Intensity_{tp}"] = intensity
        if i < len(items) - 1:
            next_tp, next_intensity = items[i + 1]
            sym = ""
            if next_intensity > intensity:
                sym = "<"
                if intensity == 0 and next_intensity > 0:
                    sym = "<<"
                elif intensity > 0 and next_intensity >= 10 * intensity:
                    sym = "<<"
            elif next_intensity < intensity:
                sym = ">"
                if next_intensity == 0 and intensity > 0:
                    sym = ">>"
                elif next_intensity > 0 and intensity >= 10 * next_intensity:
                    sym = ">>"
            change_data[f"Change_{tp}"] = sym
        else:
            change_data[f"Change_{tp}"] = ""
    return change_data, zero_count, peak_over_threshold

def sort_timepoints(names: list[str]) -> list[str]:
    def key_fn(s: str):
        m = re.match(r"^\s*(\d+)_", s)
        return (int(m.group(1)) if m else 10**9, s)
    return sorted(names, key=key_fn)

def require_mass_intensity(df: pd.DataFrame, label: str) -> pd.DataFrame:
    if "Mass" not in df.columns or "Intensity" not in df.columns:
        raise ValueError(f"{label} must contain columns Mass and Intensity. Found: {list(df.columns)}")
    out = df.copy()
    out["Mass"] = pd.to_numeric(out["Mass"], errors="coerce")
    out["Intensity"] = pd.to_numeric(out["Intensity"], errors="coerce")
    out = out.dropna(subset=["Mass", "Intensity"]).reset_index(drop=True)
    return out

def within_ppm(m1: float, m2: float, ppm_tol: float) -> bool:
    return abs(m1 - m2) <= m2 * ppm_tol / 1e6

def custom_grouping(df: pd.DataFrame, ppm_tol: float = 5.0) -> pd.DataFrame:
    if df.empty:
        return df
    pattern_cols = [c for c in df.columns if c != "Mass"]
    grouped = df.groupby(pattern_cols, dropna=False)
    new_rows = []
    for _, group in grouped:
        group = group.sort_values("Mass").reset_index(drop=True)
        subgroups = [[float(group.loc[0, "Mass"])]]
        for i in range(1, len(group)):
            m = float(group.loc[i, "Mass"])
            placed = False
            for sg in subgroups:
                if within_ppm(sg[0], m, ppm_tol):
                    sg.append(m)
                    placed = True
                    break
            if not placed:
                subgroups.append([m])
        for sg in subgroups:
            template = group.iloc[0].copy()
            template["Mass"] = float(sum(sg) / len(sg))
            new_rows.append(template)
    return pd.DataFrame(new_rows).reset_index(drop=True)

def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    ##
    ppm_tol_match = 10.0
    mass_merge_ppm = 5.0 
    max_zero_allowed = 3  
    intensity_threshold = 2000.0
    ##
    if not DATA_DIR.exists():
        raise FileNotFoundError(f"Missing folder: {DATA_DIR}. Upload your CSVs there.")
    files = sorted(DATA_DIR.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV files found in {DATA_DIR}")
    timepoint_tables = {}
    for fp in files:
        tp = fp.stem
        df = require_mass_intensity(pd.read_csv(fp), fp.name)
        timepoint_tables[tp] = df
    timepoints = sort_timepoints(list(timepoint_tables.keys()))
    print("Timepoints order:")
    for t in timepoints:
        print("  -", t)
    all_masses = []
    for tp in timepoints:
        all_masses.extend(timepoint_tables[tp]["Mass"].astype(float).tolist())
    all_masses = sorted(set(all_masses))
    matched_rows = []
    for mass in all_masses:
        intensity_map = {}
        for tp in timepoints:
            intensity_map[tp] = find_matching_intensity(mass, timepoint_tables[tp], ppm_tol_match)
        change_data, zero_count, peak_over = format_intensity_change(intensity_map)
        peak_over = any(v > intensity_threshold for v in intensity_map.values())
        if peak_over and zero_count <= max_zero_allowed:
            matched_rows.append({"Mass": float(mass), **change_data})
    results_df = pd.DataFrame(matched_rows)
    aggregated_df = custom_grouping(results_df, ppm_tol=mass_merge_ppm)
    out_csv = RESULTS_DIR / "Intensity_changes_report_full.csv"
    aggregated_df.to_csv(out_csv, index=False)
    print(f"Saved: {out_csv}")
    print(f"Rows:  {len(aggregated_df)}")

if __name__ == "__main__":
    main()